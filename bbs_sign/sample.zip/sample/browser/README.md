# bbs-signatures-sample-browser

A simple runnable sample demoing how the API can be invoked in browser, output is shown in console of browser

Run the following and navigate to developer tools in browser to observe the output

```
yarn install --frozen-lockfile
yarn demo
open http://localhost:8080
```
