# jsonld-signatures-bbs-sample

A simple runnable sample demoing how to use the API.

Run the following and observe the console output for a JSON-LD document with a single proof

```
yarn install --frozen-lockfile
yarn demo
```

Run the following and observe the console output for a JSON-LD document with multiple proofs

```
yarn install --frozen-lockfile
yarn demo:multi
```
